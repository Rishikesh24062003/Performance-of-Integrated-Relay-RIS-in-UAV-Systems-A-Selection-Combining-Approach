clear all;
clc;

% Parameters
M = 1e6; % Number of symbols
Pt_dB = 0:5:50; % Transmit power in dB
Pt = 10.^(Pt_dB/10); % Transmit power in linear scale
No = 1; % Noise power
m = 1; % Nakagami-m fading parameter
omega = 1; % Omega parameter for Nakagami-m distribution
N = 64; % Number of reflecting elements in IRS
SNR_th_dB = -10; % Threshold SNR in dB
SNR_th = 10^(SNR_th_dB/10); % Threshold SNR in linear scale

% Free Space Path Loss parameters
d1 = 20; % Distance from source to relay/IRS in meters
d2 = 30; % Distance from relay/IRS to destination in meters
f = 1.6e9; % Frequency in Hz (1.6 GHz)
c = 3e8; % Speed of light in m/s
lambda = c / f; % Wavelength

% Gains (assuming unity gains for simplicity)
G_s = 1; G_r = 1; G_d = 1;

% Path Losses (Free Space Path Loss)
PL1 = (G_s * G_r * lambda) / (4 * pi * d1^2);
PL2 = (G_d * G_r * lambda) / (4 * pi * d2^2);
PL_IRS = (lambda^2 * sqrt(G_s * G_d)) / (16 * pi * d1 * d2);

% Initialize the outage probability array
OutageProb = zeros(1, length(Pt_dB));

for jj = 1:length(Pt)
    % Generate Nakagami-m fading coefficients for relay
    h1 = sqrt(gamrnd(m, omega/m, 1, M));
    h2 = sqrt(gamrnd(m, omega/m, 1, M));
    
    % Apply path loss
    h1f = sqrt(PL1) * h1;
    h2f = sqrt(PL2) * h2;
    h_relay = min(abs(h1f), abs(h2f)); % Min selection combining

    % Generate Nakagami-m fading coefficients for IRS with N elements
    hi = sqrt(gamrnd(m, omega/m, [N, M])); 
    gi = sqrt(gamrnd(m, omega/m, [N, M]));

    % Calculate the combined IRS channel effect
    h_IRS = PL_IRS * sum(hi .* gi, 1);

    % Select the better channel for communication
    h_final = max(h_relay, abs(h_IRS));

    % Calculate instantaneous SNR
    inst_SNR = Pt(jj) * (abs(h_final).^2) / No;

    % Calculate outage probability
    OutageProb(jj) = mean(inst_SNR < SNR_th);
end

% Plotting Outage Probability results
figure;
semilogy(Pt_dB, OutageProb, 'r-s', 'LineWidth', 1.5);
xlabel('Transmit Power (dB)');
ylabel('Outage Probability');
title('Outage Probability vs Transmit Power for Nakagami-m Fading Channel with UAV Relay and IRS');
grid on;
