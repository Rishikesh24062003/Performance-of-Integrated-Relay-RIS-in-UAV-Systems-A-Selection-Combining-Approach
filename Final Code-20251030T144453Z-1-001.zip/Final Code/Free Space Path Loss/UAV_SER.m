clear all;
clc;

% Parameters
M = 10^6; % Number of symbols
Pt_dB = -20:5:30; % Transmit power in dB
Pt = 10.^(Pt_dB/10); % Transmit power in linear scale
No = 1; % Noise power
m = 2; % Nakagami-m fading parameter
omega = 1; % Omega parameter for Nakagami-m distribution
N = 32; % Number of reflecting elements in IRS
SNR_th_dB = 10; % Threshold SNR in dB
SNR_th = 10^(SNR_th_dB/10); % Threshold SNR in linear scale

% Free Space Path Loss parameters
d1 = 10; % Distance from source to relay/IRS in meters
d2 = 10; % Distance from relay/IRS to destination in meters
f = 1.6e9; % Frequency in Hz (1.6 GHz)
c = 3e8; % Speed of light in m/s
lambda = c / f; % Wavelength

% Gains (assuming unity gains for simplicity)
G_s = 1; G_r = 1; G_d = 1;

% Path Losses (Free Space Path Loss)
PL1 = (G_s * G_r * lambda) / (4 * pi * d1^2);
PL2 = (G_d * G_r * lambda) / (4 * pi * d2^2);
PL_IRS = (lambda^2 * sqrt(G_s * G_d)) / (16 * pi * d1 * d2);

% Generate BPSK symbols
ip = rand(1, M) > 0.5; % Generate 0,1 with equal probability
s = 2 * ip - 1; % BPSK modulation 0 -> -1, 1 -> 1 

% Initialize the SER array
SER = zeros(1, length(Pt_dB));

for jj = 1:length(Pt)
    % Generate Nakagami-m fading coefficients for relay
    h1 = sqrt(gamrnd(m, omega/m, 1, M));
    h2 = sqrt(gamrnd(m, omega/m, 1, M));
    
    % Apply path loss
    h1f = sqrt(PL1) * h1;
    h2f = sqrt(PL2) * h2;
    h_relay = min(abs(h1f), abs(h2f)); % Min selection combining

    % Generate Nakagami-m fading coefficients for IRS with N elements
    hi = sqrt(gamrnd(m, omega/m, [N, M])); 
    gi = sqrt(gamrnd(m, omega/m, [N, M]));

    % Calculate the combined IRS channel effect
    h_IRS = PL_IRS * sum(hi .* gi, 1);

    % Select the better channel for communication
    h_final = max(h_relay, abs(h_IRS));

    % Calculate instantaneous SNR
    inst_SNR = Pt(jj) * (abs(h_final).^2) / No;

    % Noise standard deviation
    sigma = sqrt(No / (2 * Pt(jj)));

    % Generate noise
    n = sigma * (randn(1, M) + 1j * randn(1, M)); % AWGN

    % Received signal
    r = h_final .* s + n;

    % BPSK demodulation
    sHat = real(r ./ h_final) > 0; % Equalize and make decision
    sHat = 2 * sHat - 1; % BPSK demodulation

    % Calculate SER
    SER(jj) = mean(sHat ~= s);
end

% Plotting SER results
figure;
semilogy(Pt_dB, SER, 'b-o', 'LineWidth', 1.5);
xlabel('Transmit Power (dB)');
ylabel('Symbol Error Rate');
title('Symbol Error Rate vs Transmit Power for Nakagami-m Fading Channel with UAV Relay and IRS');
grid on;
