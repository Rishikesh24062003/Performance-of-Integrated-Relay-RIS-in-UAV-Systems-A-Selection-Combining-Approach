% Parameters
M = 10000000; % Number of symbols
Pt_dB = 0:5:50; % Transmit power in dB
Pt = 10.^(Pt_dB/10); % Transmit power in linear scale
No = 1; % Noise power
m = 2; % Nakagami-m fading parameter
omega = 1; % Omega parameter for Nakagami-m distribution

% Threshold for outage probability
SNR_th_dB = 10; % Threshold SNR in dB
SNR_th = 10^(SNR_th_dB/10);

% Generate BPSK symbols
ip = rand(1, M) > 0.5; % Generate 0,1 with equal probability
s = 2 * ip - 1; % BPSK modulation 0 -> -1, 1 -> 1 

for jj = 1:length(Pt)
    % Generate Nakagami-m fading coefficients
    h1 = sqrt(omega/2/m) * (randn(1, M) + 1j*randn(1, M)) .* sqrt(gamrnd(m, 1, [1, M]));
    h2 = sqrt(omega/2/m) * (randn(1, M) + 1j*randn(1, M)) .* sqrt(gamrnd(m, 1, [1, M]));

    % Noise standard deviation
    sigma = 1 ./ (sqrt(2 * (Pt(jj) / No)));
    n1 = randn(1, M) + 1j * randn(1, M); % AWGN

    % Received signal at relay
    yR = h1 .* s + sigma .* n1;
    %calcualte snr1 and snr2
    %apply snrF = min(snr1,snr2)

    
    % Decode and forward
    sHat = real(yR ./ h1) > 0; % Equalize and make decision
    sHat = 2 * sHat - 1; % BPSK demodulation

    % Noise at destination
    n2 = randn(1, M) + 1j * randn(1, M);
    
    % Received signal at destination
    yD = h2 .* sHat + sigma .* n2;
    
    % Calculate instantaneous SNR
    SNR = Pt(jj) * min(h1,h2).^2 / No;
    %correction
    %take snr of hi and h2 and then take min of both
    
    % Outage Probability
    OutageProb(jj) = mean(SNR < SNR_th);
end

% Plotting Outage Probability results
figure;
semilogy(Pt_dB, OutageProb, 'r-s');
xlabel('Transmit Power (dB)');
ylabel('Outage Probability');
title('Outage Probability vs Transmit Power for Nakagami-m Fading Channel');
grid on;
