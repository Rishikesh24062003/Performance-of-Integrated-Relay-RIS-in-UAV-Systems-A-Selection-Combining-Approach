% Parameters
M = 10^6; % Number of symbols
Pt_dB = 0:2:50; % Transmit power in dB
Pt = 10.^(Pt_dB/10); % Transmit power in linear scale
No = 1; % Noise power
m = 2; % Nakagami-m fading parameter
omega = 1; % Omega parameter for Nakagami-m distribution

% Generate BPSK symbols
ip = rand(1, M) > 0.5; % Generate 0,1 with equal probability
s = 2 * ip - 1; % BPSK modulation 0 -> -1, 1 -> 1 

nErr = zeros(1, length(Pt)); % Initialize error count array

for jj = 1:length(Pt)
    % Generate Nakagami-m fading coefficients
    h1 = sqrt(omega/2/m) * (randn(1, M) + 1j*randn(1, M)) .* sqrt(gamrnd(m, 1, [1, M]));
    h2 = sqrt(omega/2/m) * (randn(1, M) + 1j*randn(1, M)) .* sqrt(gamrnd(m, 1, [1, M]));

    % Noise standard deviation
    sigma = 1 / sqrt(2 * Pt(jj) / No);
    n1 = randn(1, M) + 1j * randn(1, M); % AWGN

    % Received signal at relay
    yR = h1 .* s + sigma .* n1;
    
    % Amplify and forward
    gain = sqrt(Pt(jj)) ./ abs(h1); % Amplification factor to maintain the power level
    xRelay = gain .* yR; % Amplified signal

    % Noise at destination
    n2 = randn(1, M) + 1j * randn(1, M);
    
    % Received signal at destination
    yD = h2 .* xRelay + sigma .* n2;
    yHat = yD ./ (h1 .* h2); % Equalization
    ipHat = real(yHat) > 0; % Receiver decision

    % Counting the number of errors
    nErr(jj) = sum(ip ~= ipHat);
end

% Calculate SER
simSer = nErr / M;

% Plotting SER results
figure;
semilogy(Pt_dB, simSer, 'b-o');
xlabel('Transmit Power (dB)');
ylabel('Symbol Error Rate (SER)');
title('SER vs Transmit Power for Nakagami-m Fading Channel with AF Relay');
grid on;
