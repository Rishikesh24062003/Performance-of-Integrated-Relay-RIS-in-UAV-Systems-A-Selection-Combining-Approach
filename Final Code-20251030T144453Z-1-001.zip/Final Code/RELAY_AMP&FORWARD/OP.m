% Parameters
M = 10000000; % Number of symbols
Pt_dB = 0:5:50; % Transmit power in dB
Pt = 10.^(Pt_dB/10); % Transmit power in linear scale
No = 1; % Noise power
m = 2; % Nakagami-m fading parameter
omega = 1; % Omega parameter for Nakagami-m distribution

% Threshold for outage probability
SNR_th_dB = 10; % Threshold SNR in dB
SNR_th = 10^(SNR_th_dB/10);

% Generate BPSK symbols
ip = rand(1, M) > 0.5; % Generate 0,1 with equal probability
s = 2 * ip - 1; % BPSK modulation 0 -> -1, 1 -> 1 

OutageProb = zeros(1, length(Pt)); % Initialize outage probability array

for jj = 1:length(Pt)
    % Generate Nakagami-m fading coefficients
    h1 = sqrt(omega/2/m) * (randn(1, M) + 1j*randn(1, M)) .* sqrt(gamrnd(m, 1, [1, M]));
    h2 = sqrt(omega/2/m) * (randn(1, M) + 1j*randn(1, M)) .* sqrt(gamrnd(m, 1, [1, M]));

    % Noise standard deviation
    sigma = 1 / sqrt(2 * Pt(jj) / No);
    n1 = randn(1, M) + 1j * randn(1, M); % AWGN

    % Received signal at relay
    yR = h1 .* s + sigma .* n1;
    
    % Amplify and forward
    gain = sqrt(Pt(jj)) ./ abs(h1); % Amplification factor to maintain the power level
    xRelay = gain .* yR; % Amplified signal

    % Noise at destination
    n2 = randn(1, M) + 1j * randn(1, M);
    
    % Received signal at destination
    yD = h2 .* xRelay + sigma .* n2;
    
    % Calculate instantaneous SNR for each hop
    SNR1 = Pt(jj) * abs(h1).^2 / No;
    SNR2 = Pt(jj) * abs(h2).^2 / No;
    
    % Calculate effective SNR for AF relay
    SNR_AF = (SNR1 .* SNR2) ./ (SNR1 + SNR2 + 1);
    
    % Outage Probability
    OutageProb(jj) = mean(SNR_AF < SNR_th);
end

% Plotting Outage Probability results
figure;
semilogy(Pt_dB, OutageProb, 'r-s');
xlabel('Transmit Power (dB)');
ylabel('Outage Probability');
title('Outage Probability vs Transmit Power for Nakagami-m Fading Channel with AF Relay');
grid on;
